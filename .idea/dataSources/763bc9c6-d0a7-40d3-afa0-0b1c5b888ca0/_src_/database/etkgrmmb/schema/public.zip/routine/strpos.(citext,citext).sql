create function strpos(citext, citext) returns integer
LANGUAGE SQL
AS $$
SELECT pg_catalog.strpos( pg_catalog.lower( $1::pg_catalog.text ), pg_catalog.lower( $2::pg_catalog.text ) );
$$;

create function pg_catalog.substring(text, text, text) returns text
LANGUAGE SQL
AS $$
select pg_catalog.substring($1, pg_catalog.similar_escape($2, $3))
$$;
